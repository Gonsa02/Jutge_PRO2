#include "CuaIOParInt.hh"
#include "ParInt.hh"
#include <iostream>
#include <queue>
using namespace std;

void reparteix(queue<ParInt>& q, queue<ParInt>& q1, queue<ParInt>& q2) {
	int time1 = 0, time2 = 0;
	while (not q.empty()) {
		ParInt p = q.front();
		q.pop();
		if (time2 < time1) {
			time2 += p.segon();
			q2.push(p);
		}
		else {
			time1 += p.segon();
			q1.push(p);
		}
	}
}

int main() {
	queue<ParInt> q, q1, q2;
	llegirCuaParInt(q);
	reparteix(q, q1, q2);
	escriureCuaParInt(q1);
	cout << endl;
	escriureCuaParInt(q2);
}

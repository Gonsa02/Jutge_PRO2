#include "LlistaIOEstudiant.hh"

void LlegirLlistaEstudiant(list<Estudiant> &l) {
    Estudiant e;
    e.llegir();
    while (e.consultar_DNI() != 0) l.push_back(e), e.llegir();
}

void EscriureLlistaEstudiant(list<Estudiant> &l) {
    for (list<Estudiant>::const_iterator const_it = l.begin(); const_it != l.end(); ++const_it) const_it -> escriure();
}

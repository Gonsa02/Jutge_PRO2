#include "Estudiant.hh"
#include "list"

void LlegirLlistaEstudiant(list<Estudiant>& l);

void EscriureLlistaEstudiant(list<Estudiant>& l);

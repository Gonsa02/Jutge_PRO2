#include <iostream>
#include "BinTree.hh"
#include "BinTreeIOParInt.hh"
#include "ParInt.hh"
using namespace std;

int find(const BinTree<ParInt>& tree, int n, int& s) {
    if (not tree.empty()) {
	if (tree.value().primer() == n) {
	    s = tree.value().segon();
	    return 0;
	}
	int l = find(tree.left(), n, s);
	if (l != -1) return 1 + l;
	int r = find(tree.right(), n, s);
	if (r != -1) return 1 + r;
    }
    return -1;
}

int main() {
    BinTree<ParInt> b;
    read_bintree_parint(b);
    int n, s;
    while (cin >> n) {
	int height = find(b, n, s);
	if (height != -1) cout << n << ' ' << s << ' ' << height << endl;
	else cout << -1 << endl;
    }
}

#include "BinTree.hh"
#include "BinTreeIOParInt.hh"
#include "ParInt.hh"

void read_bintree_parint(BinTree<ParInt> &a) {
    ParInt p;
    p.llegir();
    if (p.primer() != 0 and p.segon() != 0) {
	BinTree<ParInt> l;
	BinTree<ParInt> r;
	read_bintree_parint(l);
	read_bintree_parint(r);
	a = BinTree<ParInt>(p, l, r);
    }
}

void write_bintree_parint(const BinTree<ParInt> &a) {
    if (not a.empty()) {
	write_bintree_parint(a.left());
	a.value().escriure();
	write_bintree_parint(a.right());
    }
}

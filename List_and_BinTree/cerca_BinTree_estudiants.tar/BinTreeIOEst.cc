#include "BinTreeIOEst.hh"
#include "BinTree.hh"
#include "Estudiant.hh"

void read_bintree_est(BinTree<Estudiant> &a) {
    Estudiant e;
    e.llegir();
    if (e.consultar_DNI() != 0 or e.consultar_nota() != 0) {
	BinTree<Estudiant> l;
	BinTree<Estudiant> r;
	read_bintree_est(l);
	read_bintree_est(r);
	a = BinTree<Estudiant>(e,l,r);
    }
}

void write_bintree_est(const BinTree<Estudiant>& a) {
    if (not a.empty()) {
        if (a.value().te_nota()) a.value().escriure();
        else cout << a.value().consultar_DNI() << " -1" << endl;
        write_bintree_est(a.left());
        write_bintree_est(a.right());
    }
}

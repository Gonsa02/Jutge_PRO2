#include "BinTree.hh"
#include "BinTreeIOEst.hh"
#include "Estudiant.hh"

int find(const BinTree<Estudiant>& b, int& nota, int dni) {
    if (not b.empty()) {
	if (b.value().consultar_DNI() == dni) {
	   if (b.value().te_nota()) nota = b.value().consultar_nota();
	   return 0;
	}
	int l = find(b.left(), nota, dni);
	int nota_r = -1;
	int r = find(b.right(), nota_r, dni);
	if (l != -1 and r != -1) {
	   if (l <= r) return 1 + l;
	   else {
	       nota = nota_r; 
	       return 1 + r;
	   }
	}
	else if (l != -1) return 1 + l;
	else if (r != -1) {
	    nota = nota_r;
	    return 1 + r;
	}
	else return -1;
    }
    return -1;
}

int main() {
    BinTree<Estudiant> b;
    read_bintree_est(b);
    int dni;
    while (cin >> dni) { 
	int nota = -1;
	int height = find(b, nota, dni);
	if (height != -1) cout << dni << ' ' << height << ' ' << nota << endl;
	else cout << dni << ' ' << -1 << endl;
    }
}

#include "LlistaIOEstudiant.hh"

void LlegirLlistaEstudiant(list<Estudiant> &l) {
    Estudiant e;
    e.llegir();
    while (not (e.consultar_DNI() == 0 and e.consultar_nota() == 0)) l.push_back(e), e.llegir();
}

#include "Estudiant.hh"
#include "LlistaIOEstudiant.hh"

int main() {
    list<Estudiant> l;
    LlegirLlistaEstudiant(l);
    int n, times = 0;
    cin >> n;
    for (list<Estudiant>::const_iterator const_it = l.begin(); const_it != l.end(); ++const_it) if (const_it -> consultar_DNI() == n) ++times;
    cout << n << ' ' << times << endl;
}

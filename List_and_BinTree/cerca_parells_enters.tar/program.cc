#include "ParInt.hh"
#include "LlistaIOParInt.hh"

int main() {
    list<ParInt> p;
    LlegirLlistaParInt(p);
    int n;
    cin >> n;
    int times = 0, value = 0;
    for (list<ParInt>::const_iterator const_it = p.begin(); const_it != p.end(); ++const_it) {
	if (const_it -> primer() == n) ++times, value += const_it -> segon();
    }
    cout << n << ' ' << times << ' ' << value << endl;
}

#include "LlistaIOParInt.hh"
#include "ParInt.hh"

void LlegirLlistaParInt(list<ParInt> &l){
    ParInt p;
    p.llegir();
    while(not(p.primer() == 0 and p.segon() == 0)){
	l.push_back(p);
	p.llegir();
    }
}

void EscriureLlistaParInt(const list<ParInt> &l){
    for (list<ParInt>::const_iterator const_it = l.begin(); const_it != l.end(); ++const_it) {
	const_it -> escriure();
    }
}
